# EV53 — website

The public site for **EV53, Inc.** — a University of Virginia spin-off delivering MG53, the body's own molecular bandage, through engineered probiotic extracellular vesicles.

Single-page static site. No build step, no dependencies. Just static files served straight from the repo.

## Files

| File | Purpose |
|---|---|
| `index.html` | The entire site (HTML, CSS, and JS inline) |
| `favicon.svg` | The repair-ring mark used as the browser icon |
| `.nojekyll` | Tells GitHub Pages to skip Jekyll and serve the files as-is |

## Deploy on GitHub Pages

1. **Create a repo** on GitHub (public or private — Pages works with both on most plans). If you want the site to live at `https://<username>.github.io/`, name the repo exactly `<username>.github.io`. Otherwise any name works and the site will live at `https://<username>.github.io/<repo>/`.

2. **Add these files to the repo root.** Either upload them through the GitHub web UI ("Add file → Upload files") or push from your machine:

   ```bash
   git init
   git add .
   git commit -m "EV53 site"
   git branch -M main
   git remote add origin https://github.com/<username>/<repo>.git
   git push -u origin main
   ```

3. **Turn on Pages.** In the repo, go to **Settings → Pages**. Under *Build and deployment*, set **Source: Deploy from a branch**, choose **Branch: `main`** and folder **`/ (root)`**, then **Save**.

4. **Wait ~1 minute**, then refresh the Pages settings screen — it will show the live URL. That's your site.

## Editing

Everything lives in `index.html`. Common edits:

- **Copy** — search the section headings (`WHAT EV53 IS`, `THE PLATFORM`, etc.) in the file and edit the text between the tags.
- **Colours** — the three brand colours are defined once at the top, in `:root`: `--navy #14213D`, `--red #C8102E`, `--gold #FFC72C`.
- **Publications** — each paper is an `<a class="pub" href="...">` block in the Publications section; the `href` is the DOI link.
- **Contact** — the contact card is near the bottom, in the `#contact` section.

## Custom domain (optional)

To use a domain like `ev53.com` instead of the github.io URL:

1. Add a file named `CNAME` (no extension) to the repo root containing just your domain, e.g. `www.ev53.com`.
2. At your domain registrar, point the domain at GitHub Pages (a `CNAME` record to `<username>.github.io`, or `A` records to GitHub's Pages IPs — GitHub's docs list the current ones).
3. Back in **Settings → Pages**, enter the domain under *Custom domain* and enable **Enforce HTTPS** once the certificate is issued.

## A note on content

This is the **public-facing** site. It deliberately leaves out anything internal or confidential — partnership strategy, prospect names, valuations, and unpublished specifics. It presents the platform, the MG53 science, the peer-reviewed publications, the team, and the brand. Keep new content to that same public bar.

MG53 evidence shown is preclinical; the site states this and frames claims as documented biological activity, not approved health claims.
